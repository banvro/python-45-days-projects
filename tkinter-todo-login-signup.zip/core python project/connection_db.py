import mysql.connector

conn = mysql.connector.connect(host = 'localhost', username='root', password='1234')
mycurser=conn.cursor()

# mycurser.execute("insert into students1 values('ty', 2 90)")
# conn.commit()

# mycurser.execute('select *from students')
# mycurser.execute("create database TodoList")
mycurser.execute('use TodoList')

# mycurser.execute('drop table TodoData')
# mycurser.execute('alter table TodoData add column id int primary key')
# result = mycurser.execute('SELECT * FROM userData')
# print(result)
try:
    mycurser.execute("SELECT * FROM userData")
    print('Table already exists')
    data=mycurser.fetchall()
    conn.commit()
    print(data)
except:
    print("Table create")
    mycurser.execute("create table userData(id int AUTO_INCREMENT primary key, title varchar(120), disc text)")
    conn.commit()
# mycurser.execute('insert into TodoData values(default, "bbbbbbb", "cccccccc")')
# mycurser.execute("alter table students modify column number text")
# conn.commit()
# mycurser.execute("delete from TodoData where id = 28")

