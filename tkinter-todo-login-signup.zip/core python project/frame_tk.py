import tkinter as tk
from connection_db import mycurser
from tkinter import messagebox
import connection_db as conn
import re
import subprocess

def reload():
    app.destroy()

    subprocess.run(["python", "frame_tk.py"])

def deleteRow(id):
    sql = "DELETE FROM TodoData WHERE id = %s"
    adr = (id,)
    mycurser.execute(sql, adr)
    conn.conn.commit()
    reload()

def todoList():
    # Clear existing entries in the listbox
    todo_listbox.delete(0, tk.END)

    mycurser.execute("SELECT * FROM TodoData")
    data = mycurser.fetchall()

    # Add header titles
    # todo_listbox.insert(tk.END, "{:<10} {:<30} {:<30} {:<10}".format("S.No", "Title", "Description", "Action"))
    
    # Populate data
    for i, row in enumerate(data, start=1):
        # Create a frame for each todo item
        todo_frame = tk.Frame(todo_listbox)
        todo_frame.pack(fill=tk.X)

        # Add todo item to the frame
        todo_label = tk.Label(todo_frame, text="{:<10} {:<40} {:<40}".format(i, row[1], row[2]))
        todo_label.pack(side=tk.LEFT)

        # Add delete button to the frame
        delete_button = tk.Button(todo_frame, text="Delete", font=("robort", 8), command=lambda id=row[0]: deleteRow(id))
        delete_button.pack(side=tk.RIGHT)

    # Increase text size for the listbox
    todo_listbox.config(font=("robort", 40))


def addTodo():
    nameValidation = "[A-Za-z]+"
    matchTitle = re.match(nameValidation, entTitle.get())
    matchDisc = re.match(nameValidation, entDisc.get())

    if matchTitle is None:
        messagebox.showerror("Error", "Please enter title")
    elif matchDisc is None:
        messagebox.showerror("Error", "Please enter Description")
    else:
        sql = "INSERT INTO TodoData(title, disc) VALUES (%s, %s)"
        val = (entTitle.get(), entDisc.get())
        mycurser.execute(sql, val)
        conn.conn.commit()
        entTitle.delete(0, tk.END)
        entDisc.delete(0, tk.END)
        reload()

def logout():
    app.destroy()
    import signup

app = tk.Tk()
app.geometry("800x500")
app.title("Frame")

frame1 = tk.Frame(app, bg='white', border='10', relief='flat')
frame1.pack(fill='x')

lbl = tk.Label(frame1, text="Add Todo", font=("roboto", 35), bg='white')
lbl.pack(pady='20')

frame2 = tk.Frame(app, bg='white', border='10', relief='flat')
frame2.pack(fill='x')

lbl1 = tk.Label(frame2, text="Title", font=("roboto", 15), bg='white')
lbl1.grid(pady='10', padx=10, row=0, column=0)

lbl2 = tk.Label(frame2, text=":", font=("roboto", 15), bg='white')
lbl2.grid(pady='10', padx=10, row=0, column=1)

entTitle = tk.Entry(frame2, bg='white')
entTitle.grid(padx='0', row=0, column=2)

lblDisc = tk.Label(frame2, text="Disc", font=("roboto", 15), bg='white')
lblDisc.grid(pady='10', padx=10, row=1, column=0)

lblDisc1 = tk.Label(frame2, text=":", font=("roboto", 15), bg='white')
lblDisc1.grid(pady='10', padx=10, row=1, column=1)

entDisc = tk.Entry(frame2, bg='white')
entDisc.grid(padx='0', row=1, column=2)

btn = tk.Button(frame2, text="Add Todo", command=addTodo)
btn.grid(padx="30", row=2, column=2)

frame3 = tk.Frame(app, bg='white', border='10', relief='flat')
frame3.pack(fill='both', expand=True)

# Create a Listbox to display todos
todo_listbox = tk.Listbox(frame3, width=80)
todo_listbox.pack(fill='both', expand=True)

# Button to logout
btn1 = tk.Button(app, text='Logout', width=10, bg='white', fg='black', command=logout)
btn1.pack(pady=20)

# Populate initial list of todos
todoList()

app.mainloop()
