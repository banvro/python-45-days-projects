# Calculator
Create your own Python Calculator App using Python and tkinter.

Video Link: [https://youtu.be/QZPv1y2znZo](https://youtu.be/QZPv1y2znZo)

![Calculator App](calculator.png)

---

## Create Standalone Executable

```shell
pip install pyinstaller
pyinstaller --onefile -w calc.py
```
