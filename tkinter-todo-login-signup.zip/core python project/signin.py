import tkinter as tk
import re
from tkinter import messagebox 
from connection_db import mycurser

app = tk.Tk()
app.geometry('500x500')  
app.title("Sign In Form")  

def signIn():

    emailValdation = "[A-Za-z]+"
    matchEmail = re.match(emailValdation, entry1.get())

    if matchEmail == None: 
        messagebox.showerror("Email error", "Please enter email address")
    elif len(entry2.get()) == 0:
        # print('Length should be at least 6')
        messagebox.showerror('Email error', 'Please enter your password')
    else:
        mycurser.execute("select * from userData")
        users = mycurser.fetchall()
        registered = False
        if len(users) == 0:
            messagebox.showerror("User", "Please sign up")
        else:
            print(users)
            for i in range(0, len(users)):
                if len(users) == 0:
                    messagebox.showerror("User", "User not exist")
                elif entry1.get() == users[i][1] and entry2.get() == users[i][2]:
                    registered = True
                    app.destroy()
                    import frame_tk
            if registered == False:
                messagebox.showerror("User", "Invalid email or password")
        

lbl = tk.Label(app, text="Sign In",width=20,font=("bold", 20,), fg='black')  
lbl.pack(pady=50)  

lbl1 = tk.Label(app, text="Email",width=20,font=("bold", 10))
lbl1.place(x=62,y=100)
entry1 = tk.Entry(app)
entry1.place(x=150,y=95) 

lbl2 = tk.Label(app, text="Password",width=20,font=("bold", 10))  
lbl2.place(x=50,y=150)
entry2 = tk.Entry(app)  
entry2.place(x=150,y=145)

btn = tk.Button(app, text='Sign In',width=10,bg='white',fg='black', command=signIn)
btn.place(x=180,y=250)  
# it will be used for displaying the registration form onto the window  
app.mainloop()