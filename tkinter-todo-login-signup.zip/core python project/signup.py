import tkinter as tk
import re
from tkinter import messagebox 
from connection_db import mycurser
import connection_db as conn


app = tk.Tk()
app.geometry('500x500')  
app.title("Sing Up Form")  

# sign up function
def signUp():
    # emailValdation = "[A-Za-z]+"
    emailValdation = "[A-Z]*[a-z]+[._@]*[a-zA-Z0-9]+[@]+[a-z]*[a-z-_.]+[a-z][.][a-z]+"
    matchEmail = re.match(emailValdation, entry1.get())

    if matchEmail == None:
        messagebox.showerror("Email error", "Please enter valid email address")
    elif len(entry2.get()) < 6:
        messagebox.showerror('Email error', 'Length should be at least 6')
    elif len(entry2.get()) > 10:
        messagebox.showerror('Email error', 'Length should not be greater than 10')
    elif entry2.get() != entry3.get():
        messagebox.showerror("Email error", "Confrim password not match")
    else:
        mycurser.execute("select * from userData")
        users = mycurser.fetchall()
        alreadyRegister = False
        for i in range(0, len(users)):
                if entry1.get() == users[i][1] and entry2.get() == users[i][2]:
                    alreadyRegister = True
                    break
        if alreadyRegister == True:
            messagebox.showerror("User", "User already reagistered")
        else:
            sql = "INSERT INTO userData(email, password) VALUES (%s, %s)"
            val = (entry1.get(), entry2.get())
            mycurser.execute(sql, val)
            conn.conn.commit()
            entry1.delete(0, tk.END)
            entry2.delete(0, tk.END)
            app.destroy()
            import signin            
    
 
# call sign in page
def signIn():
    app.destroy()
    import signin



lbl = tk.Label(app, text="Sign Up",width=20,font=("bold", 20,), fg='black')  
lbl.pack(pady=50)  

lbl1 = tk.Label(app, text="Email",width=20,font=("bold", 10))
lbl1.place(x=62,y=100)
entry1 = tk.Entry(app)
entry1.place(x=150,y=95) 

lbl2 = tk.Label(app, text="Password",width=20,font=("bold", 10))  
lbl2.place(x=50,y=150)
entry2 = tk.Entry(app)  
entry2.place(x=150,y=145)  

lbl2 = tk.Label(app, text="Confirm Password",width=20,font=("bold", 10))  
lbl2.place(x=32,y=200)
entry3 = tk.Entry(app)
entry3.place(x=150,y=195)  

btn = tk.Button(app, text='Sign Up',width=10,bg='white',fg='black', command=signUp)
btn.place(x=180,y=250)

btn1 = tk.Button(app, text='Sign In',width=10,bg='white',fg='black', command=signIn)
btn1.place(x=180,y=300)

app.mainloop()
